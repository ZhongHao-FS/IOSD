//
//  CustomCell2.swift
//  ZhongHaoCE07
//
//  Created by Hao Zhong on 7/23/21.
//

import UIKit

class CustomCell2: UITableViewCell {

    @IBOutlet weak var title2: UILabel!
    @IBOutlet weak var detail2: UILabel!
    @IBOutlet weak var info2: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
