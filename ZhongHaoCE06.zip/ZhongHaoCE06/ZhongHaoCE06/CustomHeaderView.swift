//
//  CustomHeaderView.swift
//  ZhongHaoCE06
//
//  Created by Hao Zhong on 7/17/21.
//

import UIKit

class CustomHeaderView: UITableViewHeaderFooterView {

    @IBOutlet weak var headerTitle: UILabel!
    @IBOutlet weak var headerCount: UILabel!
    @IBOutlet weak var headerAddButton: UIButton!
    @IBOutlet weak var headerEditButton: UIButton!
    

}
